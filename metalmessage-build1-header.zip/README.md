# MetalMessage 🤘

## Build 1 – Header

Der erste echte v1.0-Baustein:  
WhatsApp-inspirierter Header mit 05Alex, Logo-Bubble und „schreibt...“-Status.
